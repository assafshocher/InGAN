import sys

import torch
from PIL import Image

import util
from InGAN import InGAN
from configs import Config


def reshuffle(checkpoint_path, guide_path, output_path):
    conf = Config().parse()
    gan = InGAN(conf)
    sd = torch.load(checkpoint_path)
    gan.G.load_state_dict(sd['G'])

    guide = util.read_shave_tensorize(guide_path, conf.must_divide)

    msk = (guide == -1).all(dim=1).float()

    out = torch.randn_like(guide)

    n = 2
    for i in range(n):
        out = gan.G((guide + 0. * out) * (1 - msk) + msk * 0.65 * out, guide.shape[2:], None)

    pil_out = Image.fromarray(util.tensor2im(out))
    if output_path is not None:
        pil_out.save(output_path)
    else:
        pil_out.show()


if __name__ == '__main__':
    '''
    usage:
      reshuffle <path to checkpoint> <path to guide.png> <path to output>
    '''
    output_path_ = None
    if len(sys.argv) == 4:
        output_path_ = sys.argv.pop()
    guide_path_ = sys.argv.pop()
    checkpoint_path_ = sys.argv.pop()
    # print('loading checkpoint: {}\nwith guide: {}\noutput: {}'.format(checkpoint_path_, guide_path_, output_path_))
    reshuffle(checkpoint_path_, guide_path_, output_path_)
