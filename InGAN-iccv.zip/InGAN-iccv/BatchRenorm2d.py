import torch
from torch import nn
from torch.autograd import Variable


class BatchReNorm2d(nn.Module):
    def __init__(self, num_features, eps=1e-5, momentum=0.5, affine=True, rmax=3.0, dmax=5.0):
        super(BatchReNorm2d, self).__init__()
        self.num_features = num_features
        self.eps = eps
        self.momentum = momentum
        self.affine = affine
        self.rmax = rmax
        self.dmax = dmax

        if self.affine:
            self.weight = nn.Parameter(torch.Tensor(num_features))
            self.bias = nn.Parameter(torch.Tensor(num_features))
        else:
            self.weight = 1.0
            self.bias = 0.0

        self.register_buffer('running_mean', torch.zeros(num_features))
        self.register_buffer('running_var', torch.ones(num_features))
        self.register_buffer('r', torch.ones(num_features))
        self.register_buffer('d', torch.zeros(num_features))

        self.reset_parameters()

    def reset_parameters(self):
        self.running_mean.zero_()
        self.running_var.zero_()
        self.r.fill_(1)
        self.d.zero_()
        if self.affine:
            self.weight.data.uniform_()
            self.bias.data.zero_()

    def _check_input_dim(self, input_tensor):
        if input_tensor.size(1) != self.running_mean.nelement():
            raise ValueError('got {}-feature tensor, expected {}'
                             .format(input_tensor.size(1), self.num_features))

    def forward(self, input_tensor):
        self._check_input_dim(input_tensor)
        n = input_tensor.shape[0] * input_tensor.shape[2] * input_tensor.shape[3]

        if self.training:
            mean = input_tensor.transpose(0, 1).contiguous().view(input_tensor.size(1), -1).mean(1)
            var = torch.sum((input_tensor - mean[None, :, None, None]) ** 2, dim=(0, 2, 3)) / (n - 1)
            std = torch.sqrt(var)
            inv_std = 1. / (std + self.eps)

            self.running_mean += self.momentum * (mean.data - self.running_mean)
            self.running_var += self.momentum * (var.data - self.running_var)

            r = (std.data / torch.sqrt(self.running_var)).clamp(1. / self.rmax, self.rmax)
            d = ((mean.data - self.running_mean) / torch.sqrt(self.running_var)).clamp(-self.dmax, self.dmax)

        else:
            mean = Variable(self.running_mean)
            var = self.running_var
            std = torch.sqrt(var)
            inv_std = 1. / (std + self.eps)

            r = 1.0
            d = 0.0

        mean = mean[None, :, None, None]
        inv_std = inv_std[None, :, None, None]
        weight = self.weight[None, :, None, None]
        bias = self.bias[None, :, None, None]
        r = Variable(r)[None, :, None, None].detach()
        d = Variable(d)[None, :, None, None].detach()

        input_normalized = (input_tensor - mean) * inv_std
        input_normalized_fixed = input_normalized * r + d
        return input_normalized_fixed * weight + bias

    def __repr__(self):
        return ('{name}({num_features}, eps={eps}, momentum={momentum},'
                'affine={affine}, rmax={rmax}, dmax={dmax})'
                .format(name=self.__class__.__name__, **self.__dict__))
